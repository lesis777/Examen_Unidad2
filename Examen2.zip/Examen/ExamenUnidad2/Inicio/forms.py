from django.forms import ModelForm
from .models import Ciudad, Equipos, Estadio


class CrearFormularioCiudad(ModelForm):
    class Meta:
        model=Ciudad
        fields=['nombre']

class CrearFormularioEquipo(ModelForm):
    class Meta:
        model=Equipos
        fields=['nombre']

class CrearFormularioEstadio(ModelForm):
    class Meta:
        model=Estadio
    
        fields=['nombre']